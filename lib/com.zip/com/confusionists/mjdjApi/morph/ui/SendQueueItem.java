package com.confusionists.mjdjApi.morph.ui;

import com.confusionists.mjdjApi.midi.MessageWrapper;

public class SendQueueItem {
	
	public String rightName;
	public MessageWrapper message;

}
