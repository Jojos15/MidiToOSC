/** classes for extending and using for writing your own Morph and support classes  */
package com.confusionists.mjdjApi.morph;