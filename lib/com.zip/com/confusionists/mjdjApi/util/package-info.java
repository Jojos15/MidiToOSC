/** Util and MjdjService classes, used by all API clients/extenders  */
package com.confusionists.mjdjApi.util;