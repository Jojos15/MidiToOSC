/** Midi message wrappers and utility classes, used by all API clients */
package com.confusionists.mjdjApi.midi;